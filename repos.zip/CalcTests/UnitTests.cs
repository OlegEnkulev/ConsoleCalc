﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using CalcLib;

namespace CalcTests
{
    [TestClass]
    public class UnitTests
    {
        [TestMethod]
        public void TestSumm()
        {
            Assert.AreEqual(10, Calculations.Summ(5, 5));
        }

        [TestMethod]
        public void TestMinus()
        {
            Assert.AreEqual(10, Calculations.Minus(15, 5));
        }

        [TestMethod]
        public void TestMulti()
        {
            Assert.AreEqual(10, Calculations.Multi(5, 2));
        }

        [TestMethod]
        public void TestDelit()
        {
            Assert.AreEqual(10, Calculations.Delit(50, 5));
        }
    }
}
