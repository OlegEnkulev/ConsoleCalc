﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLib
{
    public class CalcHistory
    {
        public double a { get; set; }
        public double b { get; set; }
        public double result { get; set; }
        public string oper { get; set; }

        public CalcHistory(double _a, string _oper, double _b, double _result)
        {
            a = _a;
            b = _b;
            result = _result;
            oper = _oper;
        }
    }
}
