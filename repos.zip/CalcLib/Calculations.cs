﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcLib
{

    public static class Calculations
    {
        public static double Summ(double a, double b)
        {
            return a + b;
        }

        public static double Minus(double a, double b)
        {
            return a - b;
        }

        public static double Multi(double a, double b)
        {
            return a * b;
        }

        public static double Delit(double a, double b)
        {
            return a / b;
        }
    }
}
